VCEP COMMERCE TRACK STUDENT SESSION PACKS
Edition 3.0

Each Session_01 to Session_24 folder contains an editable Word pack with the case study, source records where relevant, response templates, team activity, AI record and assessment checklist. Five independent practice tickets are embedded after Sessions 4, 8, 12, 16 and 20.

Faculty: upload the selected file to the college LMS or shared drive and ask each learner to create their own copy. Keep the original read-only. Publish the deadline and submission channel. Do not share the faculty textbook or unseen baseline/exit test answers.

Students: use the source case exactly as provided. Keep formula-based work in your spreadsheet and include its filename or approved link. AI is permitted only during designated practice; baseline, exit and defence are independent.

The online hub offers local-device draft saving, answer export and print. Export your work before switching devices. It does not send work to faculty automatically. Do not enter passwords, banking credentials or real client personal data.

Assessment: execution 4, reasoning 2, communication and traceability 2, professional process 2. Faculty determines acceptance and checks required control conditions.
